var a00108 =
[
    [ "SocketServer", "a00108.html#a4738379c26120fea06ffda5097485e74", null ],
    [ "SocketServer", "a00108.html#a2d6fa66afb71ef36b73924c9362c9366", null ],
    [ "~SocketServer", "a00108.html#a444c04d0b49dad7c46980458827ad786", null ],
    [ "valid", "a00108.html#a9ce605e8215ac8c86674ff808e5122ca", null ],
    [ "create", "a00108.html#a8cee5e4c17dba85469e726dc9e1b2ecb", null ],
    [ "run", "a00108.html#a6749b3d4edff32e151668a96b7e9526a", null ],
    [ "is_running", "a00108.html#a9fe5432872266827e2a8ff54c5ed8e23", null ],
    [ "shutdown", "a00108.html#a00ba987170840a33e03683b395de8046", null ],
    [ "close_connection", "a00108.html#a604aea6e43cc741b458986f65ea3dc8b", null ],
    [ "get_error_number", "a00108.html#a527fea398593c7e65003aaaf2ba5195f", null ],
    [ "get_error_message", "a00108.html#a93b5809375f451b17a4a810927f250bb", null ],
    [ "get_max_clients", "a00108.html#a7d0fba63cb6c24e2671e366f95762477", null ],
    [ "set_max_clients", "a00108.html#a4f64db6a2d8f981f7fa3bd642d97577a", null ],
    [ "insert_external_socket", "a00108.html#a665c0043bcbf2018899570bdd3d482dd", null ],
    [ "remove_external_socket", "a00108.html#a097bc51e2faed888e689d0c6c9573075", null ],
    [ "signal_connect_accept", "a00108.html#a5e69bc7e4ab2f0fd09b38f6e0b8f8682", null ],
    [ "signal_connect_receive", "a00108.html#ad39e359b534d663afa1772c8a3255dfb", null ],
    [ "signal_connect_exception", "a00108.html#a967ffd7070a642d53d009155939fe91b", null ]
];