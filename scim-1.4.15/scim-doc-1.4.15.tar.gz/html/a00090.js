var a00090 =
[
    [ "SignalSlot2", "a00090.html#aabeec0230638a36372028fbce6ecde09", null ],
    [ "call", "a00090.html#a08076d2d1f895581bdef4b015254043f", null ]
];