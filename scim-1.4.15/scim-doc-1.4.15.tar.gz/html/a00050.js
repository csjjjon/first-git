var a00050 =
[
    [ "IMEngineFactoryBase", "a00050.html#afc2a40c113d6aace917cf3233e8c76c5", null ],
    [ "~IMEngineFactoryBase", "a00050.html#af34738c7fe9e863466c25495387fb087", null ],
    [ "get_name", "a00050.html#a6921eee2666fee7ab3da416e53a7f2f6", null ],
    [ "get_uuid", "a00050.html#a7b3e039734251007df6947cf9d9b6c3a", null ],
    [ "get_icon_file", "a00050.html#adc57c3a8c80ee4bcb830fd35a7111063", null ],
    [ "get_authors", "a00050.html#a69dc66f38c39eabbade99f63467f1b6b", null ],
    [ "get_credits", "a00050.html#ac4b3d29d8b9d90dff700a795a3170db3", null ],
    [ "get_help", "a00050.html#ad077870f447a106341e252794d1709ec", null ],
    [ "create_instance", "a00050.html#aa7e2ee7629f23b4079ba1dd1e23f7dea", null ],
    [ "validate_encoding", "a00050.html#a649b93485005351fcdd3d78113af6897", null ],
    [ "validate_locale", "a00050.html#af9ca6ba3bcff44112df84cd98b02c88f", null ],
    [ "get_language", "a00050.html#acbc15b70af002f557ccd3e41496ab983", null ],
    [ "inverse_query", "a00050.html#a8e0f6c3450532bb3b4fa84de3a97c8fe", null ],
    [ "get_default_locale", "a00050.html#a2d1b1e09dcc5aa2d720505129b253b8c", null ],
    [ "get_default_encoding", "a00050.html#ab27d1aea4863f8d3fceeafaa16d5d58e", null ],
    [ "get_locales", "a00050.html#ae23b86d2be7aa7c1173b4a2b851d7afa", null ],
    [ "get_encodings", "a00050.html#a13f14e2895051ac58be1789400895921", null ],
    [ "set_locales", "a00050.html#a7d4152be0afd1a95f13973e0e180632a", null ],
    [ "set_languages", "a00050.html#abce1c79de9d82a2b14c0a45c634dc1fe", null ]
];