var a00139 =
[
    [ "SCIM_NUM_KEY_UNICODES", "a00139.html#ae38540580d05fde5030eccf49c81214e", null ],
    [ "SCIM_NUM_KEY_NAMES", "a00139.html#a6f429faa6384e66df46e3cd446dfa124", null ],
    [ "SCIM_NUM_KEY_MASKS", "a00139.html#a4faf95a5b67750ca2cf24a2372c5877f", null ],
    [ "__scim_key_to_unicode_tab", "a00139.html#a689024bdf1b31e00d696e236dc6d99ef", null ],
    [ "__scim_keys_by_code", "a00139.html#aa79cecbee182a91505cb0a70e3c67f0c", null ],
    [ "__scim_keys_by_name", "a00139.html#acf05cfca64167e686323c42b32efee08", null ],
    [ "__scim_key_mask_names", "a00139.html#afd3fc0ee5793ba10b13b3c3f52ab315e", null ]
];