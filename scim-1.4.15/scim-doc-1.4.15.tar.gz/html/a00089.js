var a00089 =
[
    [ "SignalSlot1", "a00089.html#a1306b189773c6dc6ee74636367bc92d0", null ],
    [ "call", "a00089.html#a52d521a50e8056f4a0381631f9397202", null ]
];