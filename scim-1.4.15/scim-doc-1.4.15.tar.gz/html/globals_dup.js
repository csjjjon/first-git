var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "b", "globals_b.html", null ],
    [ "n", "globals_n.html", null ],
    [ "r", "globals_r.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ],
    [ "u", "globals_u.html", null ]
];