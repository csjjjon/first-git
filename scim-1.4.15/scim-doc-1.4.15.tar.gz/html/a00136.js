var a00136 =
[
    [ "IMEngineFactoryPointer", "a00136.html#ga688a08d9d3cb1b9549b5d8254dcf53ca", null ],
    [ "IMEngineInstancePointer", "a00136.html#ga818c8e9295992f3b4226ee903f7d6f87", null ],
    [ "IMEngineSlotVoid", "a00136.html#ga34c7e02c6215d8a990b62b4fdc230131", null ],
    [ "IMEngineSlotInt", "a00136.html#ga788da0e62a764e09dadeb1a6c4e05a7d", null ],
    [ "IMEngineSlotBool", "a00136.html#ga27be9a2df43b2f1e1f4a261c38d9b6af", null ],
    [ "IMEngineSlotString", "a00136.html#ga1054865b5589d6d616b9a950cda525ad", null ],
    [ "IMEngineSlotWideString", "a00136.html#ga6a295790fb4bd60d5860ebc0ef1bbd1b", null ],
    [ "IMEngineSlotKeyEvent", "a00136.html#gae074e84d1c7ff5ae9e9f6c5ca041ca97", null ],
    [ "IMEngineSlotLookupTable", "a00136.html#ga8da3541512b5f743ba8a9823fcb232bf", null ],
    [ "IMEngineSlotProperty", "a00136.html#gaccb53d25c7c8f4b2165094a17126e17b", null ],
    [ "IMEngineSlotPropertyList", "a00136.html#ga4ad9872231cda5fdc89e883b98c2c7bc", null ],
    [ "IMEngineSlotStringTransaction", "a00136.html#ga39891ac5e52a66ea666886dc8be1bf0e", null ],
    [ "IMEngineSlotWideStringAttributeList", "a00136.html#ga1bbf0ac58b3effbb917472ea55642d3c", null ],
    [ "IMEngineSlotGetSurroundingText", "a00136.html#gafab673539103ed5ce8c7e5038a125403", null ],
    [ "IMEngineSlotDeleteSurroundingText", "a00136.html#ga375e4473d4ed9ac3c098474f94bd71d4", null ],
    [ "ClientCapability", "a00136.html#ga4f5e9e0461fb6a3dff0c2942429de97a", [
      [ "SCIM_CLIENT_CAP_ONTHESPOT_PREEDIT", "a00136.html#gga4f5e9e0461fb6a3dff0c2942429de97aa2359d0d05087f8ee07ee45e620d6f1eb", null ],
      [ "SCIM_CLIENT_CAP_SINGLE_LEVEL_PROPERTY", "a00136.html#gga4f5e9e0461fb6a3dff0c2942429de97aa8fd332bc9c9671b0e5837ae1537e1132", null ],
      [ "SCIM_CLIENT_CAP_MULTI_LEVEL_PROPERTY", "a00136.html#gga4f5e9e0461fb6a3dff0c2942429de97aaacb463b9a1b2b6e549df7d63e42d4d72", null ],
      [ "SCIM_CLIENT_CAP_TRIGGER_PROPERTY", "a00136.html#gga4f5e9e0461fb6a3dff0c2942429de97aa191cebfb0add87bf86c69192f529a8ef", null ],
      [ "SCIM_CLIENT_CAP_HELPER_MODULE", "a00136.html#gga4f5e9e0461fb6a3dff0c2942429de97aa00696b51b7322a8965227c544fd13589", null ],
      [ "SCIM_CLIENT_CAP_SURROUNDING_TEXT", "a00136.html#gga4f5e9e0461fb6a3dff0c2942429de97aae2c37e26ffd220a2ce0d65dc254a98a4", null ],
      [ "SCIM_CLIENT_CAP_ALL_CAPABILITIES", "a00136.html#gga4f5e9e0461fb6a3dff0c2942429de97aaf05fc55ea1183401d436280429bc880c", null ]
    ] ]
];