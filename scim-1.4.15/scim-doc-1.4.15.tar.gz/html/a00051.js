var a00051 =
[
    [ "IMEngineHotkeyMatcher", "a00051.html#a1505b3185fb392d08020a8dca85b003d", null ],
    [ "~IMEngineHotkeyMatcher", "a00051.html#a8ae83e63980ef7e415d67b27d58632ae", null ],
    [ "load_hotkeys", "a00051.html#a1a23cd1c1ae254c7f1e33552d14c0933", null ],
    [ "save_hotkeys", "a00051.html#a7a20fd1a4169d10e408432c9b78d0f54", null ],
    [ "add_hotkey", "a00051.html#a4d915d1fc468f7df212deb497e47764a", null ],
    [ "add_hotkeys", "a00051.html#af95f594925a941f18f9a476c781ca269", null ],
    [ "find_hotkeys", "a00051.html#a2d2031672206b73d1f1d66c35ea9cf85", null ],
    [ "get_all_hotkeys", "a00051.html#a6202a258feac822b9f7582582a7c208a", null ],
    [ "reset", "a00051.html#ade536d4b97dc9a5f3a945c9742a4b44a", null ],
    [ "clear", "a00051.html#af3a0bcd7fd2801c77d3d1a20f7c38371", null ],
    [ "push_key_event", "a00051.html#a199f816583a5e6e73878a68fb0673268", null ],
    [ "is_matched", "a00051.html#a704ec62313f196f713d229bbfc5d9ee6", null ],
    [ "get_match_result", "a00051.html#a7b4230703b423d19a2a98730e6dd6dcc", null ]
];