var a00099 =
[
    [ "Slot3", "a00099.html#a1b9e1221df4fd042f484e8981be49061", null ],
    [ "call", "a00099.html#a4a6aae9883ea1840cfcabcba72d68f75", null ],
    [ "operator()", "a00099.html#a70cd27938c44352befd99118dbbdae34", null ]
];