var a00044 =
[
    [ "HelperInfo", "a00044.html#abb6b3609d204f92b97e407f043335f7a", null ],
    [ "uuid", "a00044.html#aee1d3e3418cd830e94cae6bb71de7d05", null ],
    [ "name", "a00044.html#a1f750a8d117b026914a97b9dc6d0a46d", null ],
    [ "icon", "a00044.html#a37fa22f9b57cc36f8779cb8c20485fa1", null ],
    [ "description", "a00044.html#a4b186e71fc19875ab6bd11cb65ff9623", null ],
    [ "option", "a00044.html#ae1ecaa5236128066caae5e070241d6a4", null ]
];