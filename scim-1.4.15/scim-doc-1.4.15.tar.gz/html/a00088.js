var a00088 =
[
    [ "SignalSlot0", "a00088.html#a4f875ec6588a097792802d9db633dd88", null ],
    [ "call", "a00088.html#adcf6fa9dd6c1f2250516f1229423a941", null ]
];