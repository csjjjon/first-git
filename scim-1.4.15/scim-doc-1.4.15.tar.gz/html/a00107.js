var a00107 =
[
    [ "SocketError", "a00107.html#ab18f5ea2960bacacc7e2d693d2bcf73a", null ]
];