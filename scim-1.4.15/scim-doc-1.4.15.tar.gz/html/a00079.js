var a00079 =
[
    [ "SlotType", "a00079.html#a17db5473f018be245ebbb6697cd75bbb", null ],
    [ "connect", "a00079.html#a9758be1e7e9377a8c7e5ab4c21303000", null ],
    [ "slot", "a00079.html#a58cb45ffc945920320cab29d9b407103", null ],
    [ "emit", "a00079.html#ae5c575e7ec3ccf558a8a34dabef3edb3", null ],
    [ "operator()", "a00079.html#a4ec49357050d53e9780895730194dabc", null ]
];