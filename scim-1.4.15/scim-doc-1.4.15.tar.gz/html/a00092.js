var a00092 =
[
    [ "SignalSlot4", "a00092.html#ae67174207cb1e979078d92232bb15749", null ],
    [ "call", "a00092.html#a3131d903683849e9fc1f5ed3eb699d87", null ]
];