var globals_vars =
[
    [ "_", "globals_vars.html", null ]
];