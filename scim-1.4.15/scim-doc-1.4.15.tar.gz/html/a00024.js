var a00024 =
[
    [ "Exception", "a00024.html#aeb54505208119e580160aebb001269e4", null ],
    [ "~Exception", "a00024.html#acf04ff3e591b6164520d91e84a0d1975", null ],
    [ "what", "a00024.html#af654f4fb1b463573976fed67db111d0b", null ]
];