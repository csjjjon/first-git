var a00078 =
[
    [ "SlotType", "a00078.html#a01185a5326780fac64d67adb20555c66", null ],
    [ "connect", "a00078.html#a7665d4ae479f83b5fc6d9fe4e72ba60b", null ],
    [ "slot", "a00078.html#af6015cfa99726d9af43ad3299d398d85", null ],
    [ "emit", "a00078.html#a871336e6ed1020d6bdd2b8634a53e4dc", null ],
    [ "operator()", "a00078.html#a7a478f1748d67b9596d654f3b01008ce", null ]
];