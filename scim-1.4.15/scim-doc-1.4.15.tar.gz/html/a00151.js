var a00151 =
[
    [ "SocketServerSlotSocket", "a00151.html#ga3302e7ce1124282917597a6be5ee537c", null ],
    [ "SocketServerSignalSocket", "a00151.html#ga3e8fb05c8d4183b0660556a40a251850", null ],
    [ "SocketFamily", "a00151.html#gacc123ee748d644961e203b0794004254", [
      [ "SCIM_SOCKET_UNKNOWN", "a00151.html#ggacc123ee748d644961e203b0794004254a225d7b04097f4d180efcb8f7fe9e9d0f", null ],
      [ "SCIM_SOCKET_LOCAL", "a00151.html#ggacc123ee748d644961e203b0794004254afbb3dda14b48e951f3bff528b59857cc", null ],
      [ "SCIM_SOCKET_INET", "a00151.html#ggacc123ee748d644961e203b0794004254ac4279331823f105429a58109235e017b", null ]
    ] ],
    [ "scim_get_default_socket_frontend_address", "a00151.html#gac357603ad78841fae0b4437025b43a7b", null ],
    [ "scim_get_default_socket_imengine_address", "a00151.html#ga7aae95b6e7b86c2993dc244759cac4a9", null ],
    [ "scim_get_default_socket_config_address", "a00151.html#ga8d187ba6052af4f7b33f96ca20314790", null ],
    [ "scim_get_default_panel_socket_address", "a00151.html#gaceaef715ab0be1fa5aed4a8a761d25db", null ],
    [ "scim_get_default_helper_manager_socket_address", "a00151.html#gaf6636c8beac7b58a54d6fcd34772cd01", null ],
    [ "scim_get_default_socket_timeout", "a00151.html#ga8fc4ea36502c6697719e36b8d25bb207", null ],
    [ "scim_socket_open_connection", "a00151.html#ga90586f6824f64e0a30dfcac63ceb0f4a", null ],
    [ "scim_socket_accept_connection", "a00151.html#gaf213ad157c287344062f93dcb68a32ed", null ]
];