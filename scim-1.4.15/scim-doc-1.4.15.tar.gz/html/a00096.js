var a00096 =
[
    [ "Slot0", "a00096.html#aa6da14a418d06fae084d6e88d8277291", null ],
    [ "call", "a00096.html#a238c0b261c0386cac38dd45887559139", null ],
    [ "operator()", "a00096.html#aa111ed468218fb07cf8a7dcea942a9a5", null ]
];