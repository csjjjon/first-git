var a00019 =
[
    [ "OutType", "a00019.html#a1e9ebd20b0de267373a0205b323ac746", null ],
    [ "InType", "a00019.html#a789c1b9fade4cd929518f5d185ace573", null ],
    [ "DefaultMarshal", "a00019.html#ae641fd16a748e009c6363868fe0f919d", null ],
    [ "value", "a00019.html#a1196593e2b2eb0faa5601f2d46bc6936", null ],
    [ "marshal", "a00019.html#aab948b72902e5fbe5d995a82760a191f", null ]
];