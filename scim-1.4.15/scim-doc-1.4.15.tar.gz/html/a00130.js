var a00130 =
[
    [ "scim_global_config_read", "a00130.html#ga3402d4cab92a386b5cbb2451d6ee965f", null ],
    [ "scim_global_config_read", "a00130.html#ga9647c298a70bfb1b530729a25233ac94", null ],
    [ "scim_global_config_read", "a00130.html#ga6ee620cdca87a716146915017361b94c", null ],
    [ "scim_global_config_read", "a00130.html#gac0af6ec0ae4e65328defec24b364627a", null ],
    [ "scim_global_config_read", "a00130.html#ga90ba479032c2186c2bba33d603bb22bd", null ],
    [ "scim_global_config_read", "a00130.html#ga71fa3ba70c3acaed78eae9bc82ab86ba", null ],
    [ "scim_global_config_write", "a00130.html#gab899089a1be658932d3cb5068c63ba32", null ],
    [ "scim_global_config_write", "a00130.html#ga722773f22f962c736674267c6321df0e", null ],
    [ "scim_global_config_write", "a00130.html#gab6eb309a4aaceae1074ed835f6c34ebb", null ],
    [ "scim_global_config_write", "a00130.html#ga326317b1cdf6cf82f639b84ef6652950", null ],
    [ "scim_global_config_write", "a00130.html#ga8af7c226302bdea8acc23e00ad2a0a50", null ],
    [ "scim_global_config_write", "a00130.html#gac2346628ac110ae22e73a3ef0306cb96", null ],
    [ "scim_global_config_reset", "a00130.html#ga5badb1d3a1fdb8404907e2c48913ac6d", null ],
    [ "scim_global_config_flush", "a00130.html#gaadd44aedefae061911dd1084d966f104", null ]
];