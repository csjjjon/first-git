var a00163 =
[
    [ "HelperError", "a00043.html", [
      [ "HelperError", "a00043.html#ab77d824125906371e57f2f3b887de1b1", null ]
    ] ],
    [ "HelperInfo", "a00044.html", [
      [ "HelperInfo", "a00044.html#abb6b3609d204f92b97e407f043335f7a", null ],
      [ "uuid", "a00044.html#aee1d3e3418cd830e94cae6bb71de7d05", null ],
      [ "name", "a00044.html#a1f750a8d117b026914a97b9dc6d0a46d", null ],
      [ "icon", "a00044.html#a37fa22f9b57cc36f8779cb8c20485fa1", null ],
      [ "description", "a00044.html#a4b186e71fc19875ab6bd11cb65ff9623", null ],
      [ "option", "a00044.html#ae1ecaa5236128066caae5e070241d6a4", null ]
    ] ],
    [ "HelperAgent", "a00042.html", [
      [ "HelperAgent", "a00042.html#a1b20738bf66e47fa8b9ecdf083f26caf", null ],
      [ "~HelperAgent", "a00042.html#a005c687db22fd3d42c530606178c7515", null ],
      [ "open_connection", "a00042.html#aa45676e865f37d2338738a8599ceb457", null ],
      [ "close_connection", "a00042.html#a2bc2fc938c2bd4e3a7a9a5aa3ea45dc2", null ],
      [ "get_connection_number", "a00042.html#ad755e813501c0630345c008abebc50f5", null ],
      [ "is_connected", "a00042.html#a9b9eedaee2d04983dc5a0f2076891bd3", null ],
      [ "has_pending_event", "a00042.html#ab22321fb4262d89f524e192a9f4ac0ed", null ],
      [ "filter_event", "a00042.html#a9a57130bd77b87518834507005d87df1", null ],
      [ "reload_config", "a00042.html#a08fa441168f9448da5ff0097befacba3", null ],
      [ "register_properties", "a00042.html#aafbed5300bc51c29d7ed362bb315e5a0", null ],
      [ "update_property", "a00042.html#ad37175db2a3edc9f0c3aa9ef4e01a61b", null ],
      [ "send_imengine_event", "a00042.html#a70af3580d1caaf46b2ba24387617f584", null ],
      [ "send_key_event", "a00042.html#a6c7e748c83532e7975da69f788932498", null ],
      [ "forward_key_event", "a00042.html#a3f1b91c0830ac5f9722905bc3dd97b9d", null ],
      [ "commit_string", "a00042.html#a260e49eecabddb6fe3120645b915ebb6", null ],
      [ "signal_connect_exit", "a00042.html#ad4729b7edcb5dd7f1736ea36c3807b7b", null ],
      [ "signal_connect_attach_input_context", "a00042.html#a0d3474521c2a7a10f8adbaf52b06f96a", null ],
      [ "signal_connect_detach_input_context", "a00042.html#a30a15fe30a1c8d8a7fe627f631c4cbc9", null ],
      [ "signal_connect_reload_config", "a00042.html#a24c81302c47ff004ad725cb431eb5a8f", null ],
      [ "signal_connect_update_screen", "a00042.html#ae8b50c20f0ed142907fc3c9ca24c297f", null ],
      [ "signal_connect_update_spot_location", "a00042.html#a106c8d4af72dd36c11d23e50bba6f16a", null ],
      [ "signal_connect_trigger_property", "a00042.html#abbbb50a113d7b0cfbd2d837857720d23", null ],
      [ "signal_connect_process_imengine_event", "a00042.html#a9821c4aeb68b7f4967ca0f533c7be819", null ]
    ] ],
    [ "HelperManager", "a00045.html", [
      [ "HelperManager", "a00045.html#a14f73d33ca3f6ba14b79645e6d96c98c", null ],
      [ "~HelperManager", "a00045.html#aa271817b7be5ae7a4d1a107e208cb3e9", null ],
      [ "number_of_helpers", "a00045.html#ae12de3da8a4b004b2232419c6515629a", null ],
      [ "get_helper_info", "a00045.html#a0a16de9cd1dcc2faf12edf9565d472b7", null ],
      [ "run_helper", "a00045.html#ae3cf943456f1a67d543c0e9dd79bb2df", null ]
    ] ],
    [ "HelperModule", "a00046.html", [
      [ "HelperModule", "a00046.html#aee7cf95976a18c973b59ea354bcd3864", null ],
      [ "load", "a00046.html#a10b354f6aed301be7ff75e84a4818fce", null ],
      [ "unload", "a00046.html#ad3b19beb4665996c94d3e7452d282bd0", null ],
      [ "valid", "a00046.html#a4fbaa4a30c6876417a9ec7b46f694952", null ],
      [ "number_of_helpers", "a00046.html#afdd7bfc4cfc38a5771a81c24a081e0f1", null ],
      [ "get_helper_info", "a00046.html#a13813d36365ebefecbd3c0e255cb0601", null ],
      [ "run_helper", "a00046.html#a14523ff3221861551dc6118bc772d9da", null ]
    ] ],
    [ "HelperAgentSlotVoid", "a00163.html#ga5a51aa145841b0b46674ab6996fb51bd", null ],
    [ "HelperAgentSlotString", "a00163.html#ga621e13292b0fa86ab6c6a875b3bf3874", null ],
    [ "HelperAgentSlotInt", "a00163.html#gabe6cf2f9cfb9d2105f981e0f6a15df3f", null ],
    [ "HelperAgentSlotIntInt", "a00163.html#ga44c1e482392c8ff002350cd299ff706d", null ],
    [ "HelperAgentSlotTransaction", "a00163.html#gaed047c6d43b2cad15484d0920c47af43", null ],
    [ "HelperModuleNumberOfHelpersFunc", "a00163.html#ga21430085a8c6a093715049618cb12505", null ],
    [ "HelperModuleGetHelperInfoFunc", "a00163.html#ga617ced2b889747b31e6861f207493bb4", null ],
    [ "HelperModuleRunHelperFunc", "a00163.html#gaac0ea80f0398628e55aae9b2d24a4e71", null ],
    [ "scim_get_helper_module_list", "a00163.html#gae8b8feb4c9d8de960bdbee9f8c153ab2", null ],
    [ "SCIM_HELPER_STAND_ALONE", "a00163.html#gafbfb584762577b5bdf051b5b2c556922", null ],
    [ "SCIM_HELPER_AUTO_START", "a00163.html#ga69c1633a3ce3c2bd2ffb435dac55e3cd", null ],
    [ "SCIM_HELPER_AUTO_RESTART", "a00163.html#ga1fff7377de7aad93917855a55d7f7f76", null ],
    [ "SCIM_HELPER_NEED_SCREEN_INFO", "a00163.html#ga1457d0f30f2c644db97be2b0a3cd006e", null ],
    [ "SCIM_HELPER_NEED_SPOT_LOCATION_INFO", "a00163.html#ga2fcc978e52b8c6d850fd7328c9535de4", null ]
];