var modules =
[
    [ "Accessories", "a00158.html", "a00158" ],
    [ "SignalSlot", "a00159.html", "a00159" ],
    [ "IMEngine", "a00160.html", "a00160" ],
    [ "Config", "a00161.html", "a00161" ],
    [ "FrontEnd", "a00162.html", "a00162" ],
    [ "Helper", "a00163.html", "a00163" ],
    [ "Panel", "a00164.html", "a00164" ],
    [ "SocketCommunication", "a00165.html", "a00165" ],
    [ "TransactionCommands", "a00166.html", "a00166" ]
];