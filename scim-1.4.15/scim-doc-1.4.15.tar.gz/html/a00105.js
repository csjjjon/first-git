var a00105 =
[
    [ "SocketAddress", "a00105.html#a9584c7c3f4c52fcdae9d1d39e3c41156", null ],
    [ "SocketAddress", "a00105.html#a27142eebf8ddf728cbab642581eed0d7", null ],
    [ "~SocketAddress", "a00105.html#a2cf7bb56ed00c2e0e6baebaa783b6bb5", null ],
    [ "operator=", "a00105.html#ae86cacdff5f902eb76712304982e39fc", null ],
    [ "valid", "a00105.html#a4a74c490395fb7bda21192361fdccfab", null ],
    [ "get_family", "a00105.html#ab4ae2f8d80452976cb2227291b22d72c", null ],
    [ "set_address", "a00105.html#a884e26503d63a7af69a38edcf09560e2", null ],
    [ "get_address", "a00105.html#ae6cf70868c50921ca00678157df65760", null ],
    [ "get_data", "a00105.html#ac5d13175436662edf943e784d74916cc", null ],
    [ "get_data_length", "a00105.html#a980ab6265992ea40a797a2293ff99fe5", null ]
];