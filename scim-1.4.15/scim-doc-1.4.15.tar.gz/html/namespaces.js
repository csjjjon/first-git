var namespaces =
[
    [ "scim", "a00157.html", null ]
];