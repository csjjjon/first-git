var a00104 =
[
    [ "Socket", "a00104.html#a6a721741969f034798d8f3caa8d99701", null ],
    [ "~Socket", "a00104.html#ab0a7b7a9bf43e105a3174d0e18f43396", null ],
    [ "valid", "a00104.html#a67cc37277954490606457962a4ba0b3e", null ],
    [ "read", "a00104.html#a92f25c4dbeed0ea9fa2e89b847d84fd9", null ],
    [ "read_with_timeout", "a00104.html#a2fa62b20ba4e9b448940fe2673dc8d38", null ],
    [ "write", "a00104.html#abffb97ec665e1dcb39a33278159adf21", null ],
    [ "wait_for_data", "a00104.html#a52b6e6d7659fb68a5488c093e405cb13", null ],
    [ "get_error_number", "a00104.html#a94130c70583ebc25c773b81307c36ba2", null ],
    [ "get_error_message", "a00104.html#af45075e884409884b79209b57d429680", null ],
    [ "get_id", "a00104.html#a79a5a43798d532b26c043b52c72b24de", null ],
    [ "connect", "a00104.html#a83ccf9c43a44517bcfc434c0a48df9ea", null ],
    [ "bind", "a00104.html#afb84911b90127bfeb7115fefbfce37bd", null ],
    [ "listen", "a00104.html#ad80ba5a2043714bce161850dad3d70f4", null ],
    [ "accept", "a00104.html#a182fc3d0940022a022e123886a8cc6ba", null ],
    [ "create", "a00104.html#a22d62a8aaa83542200fefbf076d51272", null ],
    [ "close", "a00104.html#a5dddb2638795e45a6cc34e2d6be565c0", null ]
];