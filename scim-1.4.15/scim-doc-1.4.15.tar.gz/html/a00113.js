var a00113 =
[
    [ "SCIM_RGB_COLOR", "a00158.html#ga7c9b85f722a62ebeaa56a8b4e1433c9d", null ],
    [ "SCIM_RGB_COLOR_RED", "a00158.html#ga4a9fb93192078e71e3f1eee03d18ec22", null ],
    [ "SCIM_RGB_COLOR_GREEN", "a00158.html#ga27b793990c7973e2f0bcea2c4c81c418", null ],
    [ "SCIM_RGB_COLOR_BLUE", "a00158.html#ga49b0c68bf824ca6d2aeb9bf24d0e723f", null ],
    [ "AttributeList", "a00113.html#ga81a9bf12437e21157b5fb7dabda841fe", null ],
    [ "AttributeType", "a00113.html#gac9561a01d6d8ccee2697d02c223090cb", [
      [ "SCIM_ATTR_NONE", "a00113.html#ggac9561a01d6d8ccee2697d02c223090cba2a49a9c4ec6389aa27ed3f593b7778c1", null ],
      [ "SCIM_ATTR_DECORATE", "a00113.html#ggac9561a01d6d8ccee2697d02c223090cba46e8d096c0cc72470fc4856e84ccec01", null ],
      [ "SCIM_ATTR_FOREGROUND", "a00113.html#ggac9561a01d6d8ccee2697d02c223090cba8f0e75f0c89a877d0a516186f7c205db", null ],
      [ "SCIM_ATTR_BACKGROUND", "a00113.html#ggac9561a01d6d8ccee2697d02c223090cba64cf4700d4ceddb4a2003493afb47ba2", null ]
    ] ],
    [ "operator<", "a00113.html#gafabb325803420d1715b882c1a7bfa4d4", null ],
    [ "SCIM_ATTR_DECORATE_NONE", "a00113.html#ga82fad50de577c689942d8a0efd574379", null ],
    [ "SCIM_ATTR_DECORATE_UNDERLINE", "a00113.html#gaea9d5ce2cd39c5d3055891c5cee14e88", null ],
    [ "SCIM_ATTR_DECORATE_HIGHLIGHT", "a00113.html#ga9f653aff850f0dbf22ea10f3103995f0", null ],
    [ "SCIM_ATTR_DECORATE_REVERSE", "a00113.html#gac9b4666400e27e6e55001c08285edcc8", null ]
];