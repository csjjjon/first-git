var a00119 =
[
    [ "ConfigModuleInitFunc", "a00119.html#ga218bc3178b16e6e02b16b16428fcb2ea", null ],
    [ "ConfigModuleCreateConfigFunc", "a00119.html#ga784a88fc64d5be513dbb5e57ed4a8aa8", null ],
    [ "scim_get_config_module_list", "a00119.html#ga9a77d0ea3e46bd61606183e08ddaabfc", null ]
];