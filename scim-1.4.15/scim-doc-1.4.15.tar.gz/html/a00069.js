var a00069 =
[
    [ "PanelFactoryInfo", "a00069.html#adcadb99f56532832b7435eb09a41db4b", null ],
    [ "PanelFactoryInfo", "a00069.html#a352db46207faf45c2a172d359f03d601", null ],
    [ "uuid", "a00069.html#a0909608298a21bf63d166d2b414634c0", null ],
    [ "name", "a00069.html#ad8dbcf4922fa832a96a4062b0229675f", null ],
    [ "lang", "a00069.html#aab5d67fce28fc4dda2a8525e6f268019", null ],
    [ "icon", "a00069.html#a845a6df9957344bf35777395b650423a", null ]
];