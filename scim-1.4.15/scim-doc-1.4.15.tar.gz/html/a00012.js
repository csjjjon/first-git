var a00012 =
[
    [ "ComposeKeyFactory", "a00012.html#a4972638b61ed2ecd3432f106002cb4e4", null ],
    [ "~ComposeKeyFactory", "a00012.html#a16e8fd9d08bd5225a223708192602126", null ],
    [ "get_name", "a00012.html#a6a00b436255e3e5dda3fd940467569a2", null ],
    [ "get_uuid", "a00012.html#a4229ae829bfb9ce79df99d339dbcb818", null ],
    [ "get_icon_file", "a00012.html#ab4cec54624d68f0d012a46087ae66b2d", null ],
    [ "get_authors", "a00012.html#a16a7a4d1735ff89c37e78d65fc97031b", null ],
    [ "get_credits", "a00012.html#af26de9ffee1ebfbdca5161fece8c7d49", null ],
    [ "get_help", "a00012.html#a2fbb13b1b84952c87b743043e85d3914", null ],
    [ "validate_encoding", "a00012.html#aa0a2c89274d9b8e920002b4a3998c336", null ],
    [ "validate_locale", "a00012.html#a960cfdd285370bafd13cf313bedd0663", null ],
    [ "create_instance", "a00012.html#a3994313c8151a390834e7863286ed628", null ]
];