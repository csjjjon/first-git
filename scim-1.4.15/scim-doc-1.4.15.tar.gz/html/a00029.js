var a00029 =
[
    [ "FilterManager", "a00029.html#a86518cdc562b40d8f577451196382f9a", null ],
    [ "~FilterManager", "a00029.html#a0078c1e4002e6769f977e79a91bf6120", null ],
    [ "number_of_filters", "a00029.html#ad0cb3f944837764e966cd87af3f0c0fb", null ],
    [ "get_filter_info", "a00029.html#ae153eeb61125f82e0effd81ccb3f1577", null ],
    [ "get_filter_info", "a00029.html#aad6186b5462b6a4f958e04270875e5fd", null ],
    [ "clear_all_filter_settings", "a00029.html#ad25ac4786cbb777a530ed8a688e8db46", null ],
    [ "get_filters_for_imengine", "a00029.html#aef657c4b2da446057024b118ed39a6a7", null ],
    [ "set_filters_for_imengine", "a00029.html#ad3d5cd83207f95500925deb2ff2c733a", null ],
    [ "get_filtered_imengines", "a00029.html#a354bdb6695d255e3f9cb69dc4ac0795f", null ],
    [ "create_filter", "a00029.html#a27498f53e18c231404d4891b8a1ad1da", null ],
    [ "create_filter", "a00029.html#a4ddf74b790d842a0cce0cdc18c992dda", null ],
    [ "attach_filters_to_factory", "a00029.html#a9abe44c1a500e2b2750aa95734130c16", null ]
];