var a00085 =
[
    [ "SlotType", "a00085.html#ad51e3bb9267bd9e140a194f4b27932db", null ],
    [ "connect", "a00085.html#ad07c560c6d562397bbea6551ea3417eb", null ],
    [ "slot", "a00085.html#abc841a1ad7ccfab246f2810c1b5d1733", null ],
    [ "emit", "a00085.html#a58a127f5a1c378023bb4c6124e55ab9b", null ],
    [ "operator()", "a00085.html#affe4d2d58bdc7976c7353ed57e794bf4", null ]
];