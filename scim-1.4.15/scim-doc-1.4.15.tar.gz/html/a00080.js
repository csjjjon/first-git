var a00080 =
[
    [ "SlotType", "a00080.html#add8988c09cf3203284786e1f3aff8542", null ],
    [ "connect", "a00080.html#a21cf7c6b18c9d1f8207d3605eeb6908a", null ],
    [ "slot", "a00080.html#a1ca20b0631d940b09662f394f551995d", null ],
    [ "emit", "a00080.html#a96cd3cf066f0bfcc0f4ac0eef51101a9", null ],
    [ "operator()", "a00080.html#a1303426fb085fbf1a3fcfdae3a3ffac8", null ]
];