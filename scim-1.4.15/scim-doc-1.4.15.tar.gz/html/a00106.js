var a00106 =
[
    [ "SocketClient", "a00106.html#ada4519fe4fddb428a0d8b9ad3b1d7265", null ],
    [ "SocketClient", "a00106.html#a22ff8de009fc770657367d4b2d71c687", null ],
    [ "~SocketClient", "a00106.html#aa4d2dec65e43c0605156de4666ff7bb5", null ],
    [ "is_connected", "a00106.html#a42ec751793cdf6f097171f3a33c28d49", null ],
    [ "connect", "a00106.html#acf0418f59afc17341a63b6f8f30930da", null ],
    [ "close", "a00106.html#ae68a5465561791f1e0ae1319e16a4e3d", null ]
];