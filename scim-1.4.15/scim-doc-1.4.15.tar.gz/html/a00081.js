var a00081 =
[
    [ "SlotType", "a00081.html#a3f4a8f4b9784f16cec07a935c51b80db", null ],
    [ "connect", "a00081.html#a12d519e0d4b93d3784a1fdef4951f382", null ],
    [ "slot", "a00081.html#ad1f9b2cf3632e7834e3ed076421ab0b3", null ],
    [ "emit", "a00081.html#a92da7f7863c419a30e1eaf3d08868232", null ],
    [ "operator()", "a00081.html#a0136f550fe3190dcdd59dfa365e03f20", null ]
];