var a00082 =
[
    [ "SlotType", "a00082.html#aa45743625cff25c8c53b4ad3c6d78ade", null ],
    [ "connect", "a00082.html#a6ba3b560d34d7097edd2b6c08bf29b95", null ],
    [ "slot", "a00082.html#a94bedf27a919569aea2b810db92bb1ff", null ],
    [ "emit", "a00082.html#a27aa94141d2f7188badb389d85e5c484", null ],
    [ "operator()", "a00082.html#a7d2c7b0f041e8db9f71a3907e915d30c", null ]
];