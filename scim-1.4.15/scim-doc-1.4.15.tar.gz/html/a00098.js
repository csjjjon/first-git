var a00098 =
[
    [ "Slot2", "a00098.html#ac240204092800867c067dd7eb6e6c923", null ],
    [ "call", "a00098.html#a1aeb51b15514976abf653ce327f38ccc", null ],
    [ "operator()", "a00098.html#a2530d49fa3388f819635ec8012c2baa5", null ]
];