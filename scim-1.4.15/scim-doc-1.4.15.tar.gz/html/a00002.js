var a00002 =
[
    [ "BackEndBase", "a00002.html#a45ce2ec588a61720faeef5b8e2e22714", null ],
    [ "~BackEndBase", "a00002.html#a5a91c68777e4680366c24fa7c8155c6a", null ],
    [ "get_all_locales", "a00002.html#a9f055e05093edbf56d804c059e59cef4", null ],
    [ "get_factory", "a00002.html#a2813c0aaabc7816dfea3f4a51ade16c5", null ],
    [ "get_factories_for_encoding", "a00002.html#ab06881b848fad9b4d848ab608a81b5f8", null ],
    [ "get_factories_for_language", "a00002.html#a5c7bf443bbca2b2c850cbbecd15deeb8", null ],
    [ "get_default_factory", "a00002.html#a418a249fa01dff2978ed7ea721d71ffe", null ],
    [ "set_default_factory", "a00002.html#a1176b7955ded88fb1b82c0bf878c49e5", null ],
    [ "get_next_factory", "a00002.html#a15db3f2ee8f5663396146e238640bd19", null ],
    [ "get_previous_factory", "a00002.html#a152536baba6c7fdd5f4a5e3e35901070", null ],
    [ "add_factory", "a00002.html#acaa3dc525e3c465c31c45f7d408a819f", null ],
    [ "clear", "a00002.html#a101bf2c0c30b36e7434161f6fc075df4", null ]
];