var a00027 =
[
    [ "FilterInfo", "a00027.html#a5a76ace0392062d5da7cb34a8d113c59", null ],
    [ "FilterInfo", "a00027.html#a536722f984ebf1cee8f7b8084d2b78a3", null ],
    [ "uuid", "a00027.html#a806648413c21f68d35415a3cd9253d47", null ],
    [ "name", "a00027.html#af0f54daafdf7147a891500b15a43be6f", null ],
    [ "langs", "a00027.html#ad127f89c0a9c1d490be38d355baa09fe", null ],
    [ "icon", "a00027.html#ad5d1495e4f892f2d3426751062bc244e", null ],
    [ "desc", "a00027.html#a1f00030af92d6ad84cd06cbf3ef8d3e5", null ]
];