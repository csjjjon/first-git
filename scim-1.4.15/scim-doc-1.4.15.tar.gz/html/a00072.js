var a00072 =
[
    [ "ReferencedObject", "a00072.html#acb5970284a95fa54bd68f045f03d2439", null ],
    [ "~ReferencedObject", "a00072.html#a7d4894a08de693fdadc1967f357d1c11", null ],
    [ "set_referenced", "a00072.html#ae962b5a11086bf548d0ad444f18b870d", null ],
    [ "is_referenced", "a00072.html#a653403cdad716e6a250aa262b4f5b317", null ],
    [ "ref", "a00072.html#a07512157e0d29d979b901eb8777956f8", null ],
    [ "unref", "a00072.html#a35d5e67d9d037b018c7ee1c6bf23cc97", null ],
    [ "Pointer", "a00072.html#aa53dd7cc2f186a07d5befdf517976e7d", null ]
];