var a00020 =
[
    [ "OutType", "a00020.html#a7911127e6faf7ff2905cc9527c105243", null ],
    [ "InType", "a00020.html#a21bfc81674efde7273ae3c32ba358184", null ],
    [ "DefaultMarshal", "a00020.html#a84a48419fc24807f06fc4e4dcb538eb7", null ],
    [ "value", "a00020.html#ad8b7d8a39569c6ee26eb7eb8477818ce", null ],
    [ "marshal", "a00020.html#a592d8853e6ac1d7ed50feed2b80eb9d7", null ]
];