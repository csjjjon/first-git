var a00001 =
[
    [ "Attribute", "a00001.html#a789c1fb1455734a4868a77a849adee90", null ],
    [ "get_type", "a00001.html#a0ade46b285c10cb20fda448a5a12a6f0", null ],
    [ "get_value", "a00001.html#af9c39a7dcb4e3abd6f5eb1cee6893ae7", null ],
    [ "get_start", "a00001.html#a2170e22ab302f389b176003114a33de8", null ],
    [ "get_length", "a00001.html#a09548732ced5f9c3559f5df3870d54af", null ],
    [ "get_end", "a00001.html#a22dbd9112d2a9ea3281f1ca48372efa7", null ],
    [ "set_type", "a00001.html#a9d22b60c5a638c7c7645c19b1297ba81", null ],
    [ "set_value", "a00001.html#a843db3883c46b1cbc1c7d823b401f856", null ],
    [ "set_start", "a00001.html#ad3a5b3646cdd88559eca02fa5c0906c1", null ],
    [ "set_length", "a00001.html#a4c45eac92d7aca5d5d0e7ae71d6dfa82", null ]
];