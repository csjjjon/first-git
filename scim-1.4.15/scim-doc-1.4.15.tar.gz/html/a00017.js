var a00017 =
[
    [ "Connection", "a00017.html#a9b434f06b0635da7df5c09587fcd0210", null ],
    [ "Connection", "a00017.html#a2ecbb9f7506a3407f2f18abd006a7da7", null ],
    [ "Connection", "a00017.html#adcef04a87f7f51307dc1ee578d9213d9", null ],
    [ "~Connection", "a00017.html#a710625d0d2bad44491a89a48f9db0aed", null ],
    [ "operator=", "a00017.html#a7f6a21e8565a3740b4245e2435b45e20", null ],
    [ "block", "a00017.html#a430b612cb228643be75e619ec9954697", null ],
    [ "unblock", "a00017.html#ac2d8e3a0c63ae30c7f9c38813beeeff6", null ],
    [ "disconnect", "a00017.html#a71a8cd79ec637755ced226d3bac38b34", null ]
];