var a00022 =
[
    [ "DummyIMEngineFactory", "a00022.html#a9bd77bfc09348ffbe9ed8f1f2a526eba", null ],
    [ "~DummyIMEngineFactory", "a00022.html#a276eb3c3f760e0e40b348d6a0c837e5f", null ],
    [ "get_name", "a00022.html#a4b1f0c4dca2afca32bf51e999ac8248b", null ],
    [ "get_uuid", "a00022.html#aaf015cfdac0fa23729c4adbdf9143bee", null ],
    [ "get_icon_file", "a00022.html#a604b020c0369c034d12f5f21401004f1", null ],
    [ "get_authors", "a00022.html#a1b14bf683afb91d990c3f1dfe1af282f", null ],
    [ "get_credits", "a00022.html#a46f4a39c5c52c5faaab439430cac2a04", null ],
    [ "get_help", "a00022.html#a7d1a720e5dd7a61cd7e49ea60abe5392", null ],
    [ "validate_encoding", "a00022.html#a74e85a453429e9f0d3b5409df3db046f", null ],
    [ "validate_locale", "a00022.html#a798b986e7006bb368b3252cf8855898e", null ],
    [ "create_instance", "a00022.html#a9aa887267c901bb8be1b29466a1ed47c", null ]
];