var a00058 =
[
    [ "MethodSlot2", "a00058.html#a8b8d4402e55c42d4651f29dd1f7b6adc", null ],
    [ "call", "a00058.html#a364d19ea1cdfe245aae22c966910ac56", null ]
];