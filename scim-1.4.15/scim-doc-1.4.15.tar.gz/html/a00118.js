var a00118 =
[
    [ "ConfigPointer", "a00118.html#gae76ea975dc827cc24f94e6eb98a99e60", null ],
    [ "ConfigSlotVoid", "a00118.html#ga7b53d0626da49663b9a8f0f932124ccc", null ],
    [ "ConfigSignalVoid", "a00118.html#ga7d6be7449cc24b9ced6ae7ee66def310", null ]
];